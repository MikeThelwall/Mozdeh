#Adapted from: https://eight2late.wordpress.com/2015/09/29/a-gentle-introduction-to-topic-modeling-using-r/
library(tm) #text mining library - use Tools>Install packages to load if it is not found
library(SnowballC) #for the word stemming - use Tools>Install packages to load if it is not found
library(tictoc) #timing library - use Tools>Install packages to load if it is not found
library(topicmodels) #load topic models library - use Tools>Install packages to load if it is not found
library(tidytext) #Formatting library - use Tools>Install packages to load if it is not found
library(ggplot2) #Graphing library - use Tools>Install packages to load if it is not found
library(dplyr)   #Formatting library - use Tools>Install packages to load if it is not found

###############################################################################################################
#set the working directory to the YouTube project _Temp folder, path where the comments are stored. Slashes in paths \ must be doubled \\ #
#################################################################################################
setwd("E:\\moz_data\\MuseumYT50\\_Temp") #YouTube _temp folder
filteredTweetsFile <- "temporary YouTube queriesVideos.comments_AllFiltered.txt"
TextColName <- "CommentTextDisplay"

##############################################
#Everything below here can be run unmodified #
##############################################

if (TextColName !=""){
  Tweets.df <- read.csv(filteredTweetsFile, sep = "\t", header = TRUE, quote = "", skipNul=TRUE)
  Tweets.df <- Tweets.df[TextColName] #Tweets.df["Tweet.Title."]
  filteredTweetsFileTweetsOnly <- paste(filteredTweetsFile, "TweetsOnly.txt", sep="")
  write.table(Tweets.df, filteredTweetsFileTweetsOnly, row.names = FALSE, quote=FALSE) #Save just the tweets to a file
} else {
  filteredTweetsFileTweetsOnly <- filteredTweetsFile #Just read the original file if not in columns
}

con <- file(filteredTweetsFileTweetsOnly, "rt") # Connection to read file of tweets in text mode 
readLines(con, n=1) #read and throw away the first line - the heading
tweets = readLines(con) #Read all the tweets
close(con)

#Clean Text from URLs, retweets and other unwanted text
tweets = gsub("(RT|via)((?:\\b\\W*@\\w+)+)","",tweets)  #gsub("(RT|via)((?:\b\W*@\w+)+)","",tweets)
tweets = gsub("http[^[:blank:]]+", "", tweets) #Removes hyperlinks from tweets
tweets = gsub("@\\s+", "", tweets) #removes @usernames from tweets
tweets = gsub("&\\w+", "", tweets) #removes &amp; and other escape characters from tweets
#tweets = gsub("[ t]{2,}", "", tweets) #http://www.endmemo.com/program/R/gsub.php
tweets = gsub("^\\s+|\\s+$", "", tweets) #trim whitespace from start
tweets <- gsub('\\d+', '', tweets) #Removes numbers from tweets
tweets = gsub("[[:punct:]]", " ", tweets) #Removes punctuation from tweets
tweets = gsub('[^\x20-\x7E]', '', tweets) #Removes non-Ascii from tweets

#Load the tweets into a Corpus object for topic model processing and tidy text a bit more
corpus = Corpus(VectorSource(tweets))  #Corpus object from R package tm
corpus = tm_map(corpus,removePunctuation)
corpus = tm_map(corpus,tolower) #Converts tweets to lowercase
corpus = tm_map(corpus,removeWords,stopwords("english")) #Removes very common words that are not useful for topic modelling. Could also make a list of rare words and remove them
corpus = tm_map(corpus,stripWhitespace)
corpus = tm_map(corpus,stemDocument) #Converts words to shorter form, for example getting rid of plurals
#inspect the 22nd tweet as a check
print(paste("Original number of tweets:", length(corpus)))
writeLines(as.character(tweets[[22]]))
writeLines(as.character(corpus[[22]]))
writeLines(as.character(corpus[[length(corpus)-2]]))

#Create document-term matrix
dtm <- DocumentTermMatrix(corpus)
sparseValue <- .99 #To remove rare words (occuring in less than 1% of tweets) to shrink the matrix and make processing quicker
dtm <-removeSparseTerms(dtm, sparse=sparseValue) #Remove rare words to shrink the matrix and make processing quicker
#Check if dtm has emty rows (tweets with no words left after the above processing) that cause problems in topic modelling
rowTotals <- apply(dtm , 1, sum)  #Find the sum of words in each tweet (row of dtm)
if (sum(rowTotals == 0) > 0){
  #Make new version of DocumentTermMatrix without empty documents
  empty.rows <- dtm[rowTotals == 0, ]$dimnames[1][[1]]  #Make a list of tweets with no words (rows of dtm)
  corpus <- corpus[-as.numeric(empty.rows)] #Build the corpus object again, this time excluding empty tweets
  print(paste("Number of tweets after removing empty tweets:", length(corpus),". If this is 0 then comment out this section apart from the first line dtm <- DocumentTermMatrix(corpus).")) #Number of tweets left after removing empty tweets
  dtm <- DocumentTermMatrix(corpus) #Build the document-term matrix again, this time without empty tweets
  dtm <-removeSparseTerms(dtm, sparse=sparseValue) #Remove rare words again to shrink the matrix and make processing quicker
}
sink("tweetsUsed.txt") #Save a copy of the reduced set of tweets, after deleting empty tweets #Note to Mike - writeLines(as.character(corpus), con="tweetsUsed.txt") #Simpler but unusable results
for (i in 1:length(corpus)) {
  cat(i,"\t",as.character( corpus[[i]] ),"\n" )
}
sink()

#Create a vector listing the tweets and use the vector to name rows
tweetsUsed <-c(1:dtm$nrow)
for (i in 1:dtm$nrow) {
  tweetsUsed[i] <- as.character( corpus[[i]] )
}
#rownames(dtm) <- tweetsUsed #No good way to name rows to connect them to tweets yet

freq <- colSums(as.matrix(dtm)) #Sum document-term matrix matrix columns to give word frequencies
length(freq) #Report the total number of terms
ord <- order(freq,decreasing=TRUE) #create sort order (descending)
#freq[ord] #Uncomment this command to list all terms in decreasing order of freq
write.csv(freq[ord],"word_freq.csv") #Save all terms in decreasing order of freq

#The document term matrix (DTM) produced by the above code will be the main input into the LDA algorithm next 

#Set parameters for Gibbs sampling (not necessary to understand this)
burnin <- 4000
iter <- 2000
thin <- 500
seed <-list(2003,5,63,100001,765)
nstart <- 5
best <- TRUE

#Number of topics - can change this to another number to get more topics the code above does not need to be re-run if changing k
k <- 6

#Run LDA using Gibbs sampling. This takes 3 minutes for 8,000 tweets or 25 minutes for 48,000 and 55 minutes for 160,000 tweets on a fast computer - do not try for more than 8000 tweets.
tic() #start the timer
ldaOut <-LDA(dtm,k, method="Gibbs", control=list(nstart=nstart, seed=seed, best=best, burnin=burnin, iter=iter, thin=thin))
toc() #stop the timer, just for interest

#Save the results
ldaOut.topics <- as.matrix(topics(ldaOut)) #Assign tweets to topics
write.csv(ldaOut.topics,file=paste("LDAGibbs",k,"TweetsToTopics.csv")) #Save mapping of tweets (in the reduced corpus) to topics

#Save the top 10 terms in each topic
ldaOut.terms <- as.matrix(terms(ldaOut,10))
write.csv(ldaOut.terms,file=paste("LDAGibbs",k,"TopicsToTerms.csv"))

#probabilities associated with each topic assignment
topicProbabilities <- as.data.frame(ldaOut@gamma)
write.csv(topicProbabilities,file=paste("LDAGibbs",k,"TopicProbabilitiesForEachTweet.csv"))

##Optional Tidy additions from https://www.tidytextmining.com/topicmodeling.html

tweet_topics <- tidy(ldaOut, matrix = "beta")
tweet_topics #This lists some topic numbers and words (terms), showing the probability that the word is in the topic

#Makes a list of top terms for each topic
tweet_top_terms <- tweet_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

#Graphs the above list of top terms for each topic
tweet_top_terms %>%
  mutate(term = reorder(term, beta)) %>%
  ggplot(aes(term, beta, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  coord_flip()

